// Responsive Timeline
// Timeline for a personal project
// Github: https://github.com/itbruno/responsive-timeline